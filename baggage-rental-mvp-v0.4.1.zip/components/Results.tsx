'use client';
import BaggageListingForm from './BaggageListingForm';
import { Card } from './Ui';
import type { Flight } from './FlightSearch';

function Item({ f }: { f: Flight }) {
  const dep = f.departure?.iata || f.departure?.airport || '-';
  const arr = f.arrival?.iata || f.arrival?.airport || '-';
  const date = (f.departure?.scheduled || '').slice(0,10);
  return (
    <Card>
      <div style={{ display:'flex', justifyContent:'space-between', gap:12, flexWrap:'wrap' }}>
        <div>
          <div style={{ fontSize:18, fontWeight:700 }}>{f.flight?.iata} · {f.flight_status || ''}</div>
          <div style={{ opacity:.8, marginTop:4 }}>{dep} → {arr}</div>
        </div>
      </div>
      <div style={{ marginTop:12 }}>
        <BaggageListingForm flightIata={f.flight?.iata || ''} fromIata={f.departure?.iata} toIata={f.arrival?.iata} date={date} />
      </div>
    </Card>
  );
}

export default function Results({ flights }: { flights: Flight[] }) {
  if (!flights?.length) return null;
  return (
    <div style={{ display:'grid', gap:16, marginTop:16 }}>
      {flights.map((f, i) => <Item key={i} f={f} />)}
    </div>
  );
}