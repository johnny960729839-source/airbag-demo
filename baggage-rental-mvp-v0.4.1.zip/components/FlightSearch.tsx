'use client';
import { useState } from 'react';
import { format } from 'date-fns';
import { api } from '@/lib/fetcher';
import { Card, Row, Input, Button, Banner } from './Ui';

export type Flight = {
  airline?: { name?: string; iata?: string };
  flight?: { iata?: string };
  departure?: { airport?: string; iata?: string; scheduled?: string };
  arrival?: { airport?: string; iata?: string; scheduled?: string };
  flight_status?: string;
};

export default function FlightSearch({ onFound }: { onFound: (flights: Flight[]) => void }) {
  const [flight, setFlight] = useState('');
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function search(q?: { flight?: string; date?: string }) {
    const f = (q?.flight ?? flight).toUpperCase().replace(/\s+/g, '');
    const d = q?.date ?? date;
    setLoading(true);
    setError(null);
    try {
      const res = await api<{ ok: boolean; flights: Flight[]; error?: string }>(`/api/flights?flight=${encodeURIComponent(f)}&date=${encodeURIComponent(d)}`);
      onFound(res.flights || []);
      if (!res.flights?.length) setError('没有查到这个日期的该航班，试试更换日期或开启 Demo 模式。');
    } catch (e: any) {
      setError(e?.message || '搜索失败');
      onFound([]);
    } finally {
      setLoading(false);
    }
  }

  function useDemoToday() {
    const today = format(new Date(), 'yyyy-MM-dd');
    setFlight('TG102');
    setDate(today);
    search({ flight: 'TG102', date: today });
  }

  return (
    <Card>
      <Row>
        <Input placeholder="航班号（如 TG102 / CA1207）" value={flight} onChange={e=>setFlight(e.target.value)} />
        <Input type="date" value={date} onChange={e=>setDate(e.target.value)} />
        <Button disabled={loading} onClick={()=>search()}>{loading? '查询中…' : '查询航班'}</Button>
        <Button onClick={useDemoToday} type="button">一键演示（TG102）</Button>
      </Row>
      <div style={{ marginTop: 12, fontSize: 13, opacity:.8 }}>提示：若免费接口无返回，可在环境变量中将 <code>DEMO_MODE=true</code> 以走演示数据。</div>
      {error && <div style={{ marginTop:12 }}><Banner type="error" message={error} /></div>}
    </Card>
  );
}