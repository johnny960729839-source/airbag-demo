'use client';
import { useState } from 'react';
import { Card, Row, Input, Button, Banner } from './Ui';
import { useEnsureVerified } from './VerifyPhone';

export type Listing = {
  flightIata: string;
  fromIata?: string;
  toIata?: string;
  date: string;
  kg: number;
  price: number;
};

export default function BaggageListingForm({ flightIata, fromIata, toIata, date }: { flightIata: string; fromIata?: string; toIata?: string; date: string; }) {
  const [kg, setKg] = useState(10);
  const [price, setPrice] = useState(100);
  const [ok, setOk] = useState<string | null>(null);
  const ensureVerified = useEnsureVerified();

  async function submit() {
    setOk(null);
    const phone = await ensureVerified();
    if (!phone) return;
    if (kg <= 0) return alert('重量需大于 0');
    if (price < 0) return alert('价格不能为负');
    const key = 'listings';
    const arr: Listing[] = JSON.parse(localStorage.getItem(key) || '[]');
    arr.push({ flightIata, fromIata, toIata, date, kg, price });
    localStorage.setItem(key, JSON.stringify(arr));
    setOk('已发布（本地模拟）。下步可接通后台数据库。');
  }

  return (
    <Card>
      <div style={{ fontWeight:600, marginBottom:8 }}>发布本次航班的可出让行李额</div>
      <Row>
        <Input type="number" value={kg} onChange={e=>setKg(Number(e.target.value))} placeholder="可出让重量（kg）" />
        <Input type="number" value={price} onChange={e=>setPrice(Number(e.target.value))} placeholder="价格" />
        <Button onClick={submit}>发布</Button>
      </Row>
      {ok && <div style={{ marginTop:12 }}><Banner type="success" message={ok} /></div>}
    </Card>
  );
}