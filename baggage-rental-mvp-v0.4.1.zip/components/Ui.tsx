export function Card({ children }: { children: React.ReactNode }) {
  return <div style={{ background:'#121a35', border:'1px solid #223055', borderRadius:16, padding:16, boxShadow:'0 6px 18px rgba(0,0,0,.25)' }}>{children}</div>;
}

export function Row({ children, gap=12 }: { children: React.ReactNode, gap?: number }) {
  return <div style={{ display:'flex', gap, alignItems:'center', flexWrap:'wrap' }}>{children}</div>;
}

export function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} style={{ ...props.style, background:'#0b1020', border:'1px solid #2b3a63', borderRadius:10, padding:'10px 12px', color:'#e8ecf1' }} />;
}

export function Button({ children, ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button {...props} style={{ ...props.style, background:'#2a6cf0', border:'none', borderRadius:10, padding:'10px 14px', color:'#fff', cursor:'pointer', opacity: props.disabled? .6:1 }}>
    {children}
  </button>;
}

export function Banner({ type='info', message }: { type?: 'info'|'error'|'success', message: string }) {
  const colors = { info:'#1e3a8a', error:'#7f1d1d', success:'#064e3b' } as const;
  return <div style={{ background: colors[type], color:'#fff', padding:'10px 12px', borderRadius:10 }}>{message}</div>;
}