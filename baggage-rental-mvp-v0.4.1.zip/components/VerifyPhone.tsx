'use client';
import React, { createContext, useContext, useState, useRef } from 'react';
import { Card, Row, Input, Button, Banner } from './Ui';
import { setVerifiedPhone, getVerifiedPhone } from '@/lib/auth';

const Ctx = createContext<{ ensureVerified: ()=>Promise<string> }>({ ensureVerified: async ()=>'' });
export function useEnsureVerified(){ return useContext(Ctx).ensureVerified; }

export function VerifyPhoneProvider({ children }: { children: React.ReactNode }) {
  const resolver = useRef<(v: string)=>void>();
  const [open, setOpen] = useState(false);
  const [phone, setPhone] = useState('');
  const [code, setCode] = useState('');
  const [sent, setSent] = useState(false);
  const [serverCode, setServerCode] = useState('');
  const [err, setErr] = useState<string|null>(null);
  const [loading, setLoading] = useState(false);

  async function ensureVerified(): Promise<string> {
    const v = getVerifiedPhone();
    if (v?.phone) return v.phone;
    setErr(null); setOpen(true); setPhone(''); setCode(''); setSent(false); setServerCode('');
    return new Promise<string>(res=>{ resolver.current = res; });
  }

  function close(){ setOpen(false); }
  async function sendCode(){
    if (!/^\+?\d{7,15}$/.test(phone)) { setErr('请输入正确手机号（含国家码，如 +66 或 +86）'); return; }
    setLoading(true); setErr(null);
    const gen = String(Math.floor(100000 + Math.random()*900000));
    setTimeout(()=>{ setServerCode(gen); setSent(true); setLoading(false); }, 600);
  }
  function verify(){
    if (!sent) { setErr('请先获取验证码'); return; }
    if (code !== serverCode) { setErr('验证码不正确'); return; }
    setVerifiedPhone({ phone, ts: Date.now() });
    resolver.current?.(phone);
    close();
  }

  return (
    <Ctx.Provider value={{ ensureVerified }}>
      {children}
      {open && (
        <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,.45)', display:'grid', placeItems:'center', zIndex:1000 }}>
          <div style={{ width:'min(520px, 92vw)' }}>
            <Card>
              <div style={{ fontSize:18, fontWeight:700, marginBottom:8 }}>手机号快速验证</div>
              <div style={{ fontSize:13, opacity:.8, marginBottom:12 }}>一次验证即可，后续无需重复登录。</div>
              <Row>
                <Input placeholder="手机号（含国家码，如 +66... 或 +86...）" value={phone} onChange={e=>setPhone(e.target.value)} />
                <Button disabled={loading} onClick={sendCode}>{loading? '发送中…' : '获取验证码'}</Button>
              </Row>
              {sent && (
                <div style={{ marginTop:12 }}>
                  <Row>
                    <Input placeholder="输入6位验证码" value={code} onChange={e=>setCode(e.target.value)} maxLength={6} />
                    <Button onClick={verify}>验证并继续</Button>
                  </Row>
                  {process.env.NEXT_PUBLIC_DEMO_MODE === 'true' && (
                    <div style={{ marginTop:8, fontSize:12, opacity:.7 }}>演示模式验证码：<code>{serverCode}</code></div>
                  )}
                </div>
              )}
              {err && <div style={{ marginTop:12 }}><Banner type="error" message={err} /></div>}
              <div style={{ marginTop:12 }}>
                <Button onClick={close} type="button" style={{ background:'#334155' }}>取消</Button>
              </div>
            </Card>
          </div>
        </div>
      )}
    </Ctx.Provider>
  );
}