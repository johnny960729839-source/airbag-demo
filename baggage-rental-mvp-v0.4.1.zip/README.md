# 行李额租借 · 同航班 MVP v0.4

## 本地运行
```bash
pnpm i # 或 npm i / yarn
cp .env.example .env.local
# 编辑 .env.local，填入 AVIATIONSTACK_KEY，可选 DEMO_MODE=true / NEXT_PUBLIC_DEMO_MODE=true
pnpm dev
```

打开 http://localhost:3000

## Vercel 部署（自动化）
1. 把本项目上传到 GitHub（见下文“推送到 GitHub 一键脚本”）。
2. 登录 Vercel，**Import Git Repository**，选择该仓库。
3. Project → Settings → Environment Variables 添加：
   - `AVIATIONSTACK_KEY` = 你的 key（必填）
   - `DEMO_MODE` = `true`（可选；演示阶段建议先开）
   - `NEXT_PUBLIC_DEMO_MODE` = `true`（可选；演示验证码展示）
4. 每次 `git push` 到 GitHub，Vercel 会**自动构建与部署**。

## 推送到 GitHub 一键脚本（需安装 GitHub CLI `gh`）
```bash
git init
git add .
git commit -m "feat: baggage-rental-mvp v0.4"
# 把 my-baggage-mvp 替换成你的仓库名
gh repo create my-baggage-mvp --public --source . --remote origin --push
```

若未安装 `gh`，也可手动在 GitHub 网站创建空仓库，然后：
```bash
git init
git add .
git commit -m "feat: baggage-rental-mvp v0.4"
git branch -M main
git remote add origin https://github.com/<你的用户名>/<仓库名>.git
git push -u origin main
```

## 航班搜索提示
- 免费版 aviationstack 可能返回为空：
  - 用 `flight_iata` + `dep_date` 组合；
  - 无数据时使用 `DEMO_MODE=true` 先演示流程；
  - 未来可接入付费接口或备用源（AeroDataBox 等）。

## 已包含功能
- 航班搜索（含错误复位、加载态、Demo 按钮）
- 发布同航班行李额（本地存储模拟）
- **手机号 OTP 轻验证**（演示版：本地随机 6 位码，可接短信服务商）
- 渐进登录：仅在“发布/下单/联系”等动作触发验证

## 后续路线
- 接入数据库（Supabase / Vercel Postgres）
- 绑定支付与提现
- 同航班校验（登机牌 OCR）

## v0.4.1
- 切换至付费版最佳实践：HTTPS + flight_date 优先 + fields 精简；dep_date 兜底。
