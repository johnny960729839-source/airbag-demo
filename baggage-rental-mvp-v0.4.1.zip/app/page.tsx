'use client';
import { useState } from 'react';
import FlightSearch, { type Flight } from '@/components/FlightSearch';
import Results from '@/components/Results';
import { Banner } from '@/components/Ui';

export default function Page() {
  const [flights, setFlights] = useState<Flight[]>([]);

  return (
    <div>
      <h1 style={{ fontSize:28, fontWeight:800, marginBottom:16 }}>行李额租借 · 同航班 MVP</h1>
      <FlightSearch onFound={setFlights} />
      {!flights.length && (
        <div style={{ marginTop:16 }}>
          <Banner type="info" message="先查询航班。若免费接口无返回，可开启 DEMO_MODE 后点“一键演示（TG102）”。" />
        </div>
      )}
      <Results flights={flights} />
    </div>
  );
}