import { VerifyPhoneProvider } from '@/components/VerifyPhone';
export const metadata = { title: "行李额租借 MVP" };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="zh-CN">
      <body style={{ fontFamily: 'ui-sans-serif, system-ui', background:'#0b1020', color:'#e8ecf1' }}>
        <VerifyPhoneProvider>
          <div style={{ maxWidth: 920, margin: '40px auto', padding: '0 16px' }}>{children}</div>
        </VerifyPhoneProvider>
      </body>
    </html>
  );
}