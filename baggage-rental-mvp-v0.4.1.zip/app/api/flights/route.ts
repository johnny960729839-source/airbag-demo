import { NextResponse } from 'next/server';
import { flightQuerySchema } from '@/lib/validators';

const BASE = 'https://api.aviationstack.com/v1/flights'; // 付费版用 HTTPS

async function callAviationstack(params: Record<string,string>) {
  const usp = new URLSearchParams({ access_key: process.env.AVIATIONSTACK_KEY!, ...params });
  const url = `${BASE}?${usp.toString()}`;
  const resp = await fetch(url, { next: { revalidate: 0 } });
  const data = await resp.json().catch(() => ({} as any));
  if (!resp.ok) {
    const msg = (data?.error?.info || data?.error?.message || resp.statusText);
    throw new Error(`aviationstack ${resp.status} ${msg}`);
  }
  if ((data as any)?.error) {
    throw new Error((data as any).error?.info || (data as any).error?.message || 'aviationstack error');
  }
  return (data as any)?.data || [];
}

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const raw = { flight: searchParams.get('flight') || '', date: searchParams.get('date') || '' };
    const parsed = flightQuerySchema.safeParse(raw);
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0].message }, { status: 400 });
    }
    const { flight, date } = parsed.data;

    const key = process.env.AVIATIONSTACK_KEY;
    if (!key) return NextResponse.json({ error: 'missing AVIATIONSTACK_KEY' }, { status: 500 });

    const common = {
      flight_iata: flight,
      limit: '50',
      fields: [
        'airline.name','airline.iata',
        'flight.iata',
        'departure.airport','departure.iata','departure.scheduled',
        'arrival.airport','arrival.iata','arrival.scheduled',
        'flight_status'
      ].join(',')
    };

    let flights = await callAviationstack({ ...common, flight_date: date });
    if (!flights?.length) {
      flights = await callAviationstack({ ...common, dep_date: date });
    }

    return NextResponse.json({ ok: true, flights });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'unknown error' }, { status: 500 });
  }
}