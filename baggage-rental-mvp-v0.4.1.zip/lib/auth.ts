export type VerifiedPhone = { phone: string; ts: number };

const KEY = 'verifiedPhone';
export function getVerifiedPhone(): VerifiedPhone | null {
  try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch { return null; }
}
export function setVerifiedPhone(v: VerifiedPhone) {
  localStorage.setItem(KEY, JSON.stringify(v));
}
export function isVerified() { return !!getVerifiedPhone()?.phone; }