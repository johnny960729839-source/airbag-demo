import { z } from 'zod';

export const flightQuerySchema = z.object({
  flight: z.string()
    .transform(s => s.trim().toUpperCase().replace(/\s+/g, ''))
    .refine(v => /^[A-Z]{2,3}\d{1,4}$/.test(v), '航班号格式不正确，如 TG102 / CA1207'),
  date: z.string().refine(v => /^\d{4}-\d{2}-\d{2}$/.test(v), '日期格式应为 YYYY-MM-DD')
});

export type FlightQuery = z.infer<typeof flightQuerySchema>;